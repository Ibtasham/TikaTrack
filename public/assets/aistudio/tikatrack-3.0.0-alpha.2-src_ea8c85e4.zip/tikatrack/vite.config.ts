import { createHash } from 'node:crypto';
import { readdir, readFile } from 'node:fs/promises';
import { fileURLToPath, URL } from 'node:url';
import { join } from 'node:path';

import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import { defineConfig, type Plugin } from 'vite';

/**
 * Where the app is served from. Set `VITE_BASE` for a sub-path deploy, e.g.
 * GitHub Pages project sites:
 *
 *   VITE_BASE=/tikatrack/ npm run build
 *
 * Vite requires a leading and trailing slash, so normalise whatever was passed.
 */
function resolveBase(): string {
  const raw = process.env.VITE_BASE || '/';
  const withLeadingSlash = raw.startsWith('/') ? raw : `/${raw}`;
  return withLeadingSlash.endsWith('/') ? withLeadingSlash : `${withLeadingSlash}/`;
}

const base = resolveBase();

const PUBLIC_DIR = fileURLToPath(new URL('./public', import.meta.url));

/** Every file in `public/`, as root-relative URLs (`/icons/icon-192.png`). */
async function listPublicFiles(dir: string, prefix = ''): Promise<string[]> {
  let entries;
  try {
    entries = await readdir(dir, { withFileTypes: true });
  } catch {
    return []; // no public directory — nothing to precache from it
  }

  const files: string[] = [];
  for (const entry of entries) {
    const path = prefix ? `${prefix}/${entry.name}` : entry.name;
    if (entry.isDirectory()) files.push(...(await listPublicFiles(join(dir, entry.name), path)));
    else files.push(`/${path}`);
  }
  return files;
}

/**
 * Emit `dist/404.html` from `404.template.html` with the deploy base baked in.
 *
 * GitHub Pages has no rewrite rules, so it serves `404.html` for every unknown
 * path. That page bounces to the app root with the original location in
 * `?tikatrack_route=`, which `src/lib/spaRedirect.ts` restores before React
 * Router mounts. It has to be *generated* rather than dropped in `public/`:
 * the redirect target needs the base path, which is only known at build time.
 */
function spaFallback(): Plugin {
  const templatePath = fileURLToPath(new URL('./404.template.html', import.meta.url));

  return {
    name: 'tikatrack:spa-fallback',
    apply: 'build',
    async generateBundle() {
      const template = await readFile(templatePath, 'utf8');
      this.emitFile({
        type: 'asset',
        fileName: '404.html',
        source: template.split('{{BASE}}').join(base),
      });
    },
  };
}

/**
 * Generate the two PWA artefacts that must know the deploy base:
 *
 *   `manifest.webmanifest` — `start_url`/`scope`/icon paths. A manifest with a
 *                            hard-coded `/` silently breaks "Add to home
 *                            screen" on a project site, so it is templated.
 *   `sw.js`                — the service worker, with a precache list built from
 *                            the bundle itself and a cache name derived from
 *                            that list (so a new deploy busts the old cache and
 *                            an identical rebuild does not).
 *
 * The manifest is also served in dev (middleware) and injected into `index.html`
 * with the right prefix, so there is exactly one source of truth:
 * `manifest.template.json`.
 */
function pwaAssets(): Plugin {
  const manifestPath = fileURLToPath(new URL('./manifest.template.json', import.meta.url));
  const swPath = fileURLToPath(new URL('./sw.template.js', import.meta.url));
  const manifestHref = `${base}manifest.webmanifest`;

  const renderManifest = async (): Promise<string> =>
    (await readFile(manifestPath, 'utf8')).split('{{BASE}}').join(base);

  return {
    name: 'tikatrack:pwa-assets',
    // Must see the HTML entry Vite emits, so run after the core plugins.
    enforce: 'post',

    // Vite already rewrites root-relative asset URLs in index.html with the
    // base, so only the manifest link is injected here.
    transformIndexHtml() {
      return [{ tag: 'link', attrs: { rel: 'manifest', href: manifestHref }, injectTo: 'head' }];
    },

    configureServer(server) {
      server.middlewares.use((request, response, next) => {
        const pathname = (request.url ?? '').split('?')[0];
        if (pathname !== manifestHref) return next();
        renderManifest()
          .then((body) => {
            response.setHeader('Content-Type', 'application/manifest+json');
            response.end(body);
          })
          .catch(next);
      });
    },

    async generateBundle(_options, bundle) {
      this.emitFile({
        type: 'asset',
        fileName: 'manifest.webmanifest',
        source: await renderManifest(),
      });

      // Everything the shell needs to render offline: emitted files (minus
      // source maps, which are a debugging convenience, not app shell), the
      // copied `public/` assets and the manifest itself.
      const emitted = Object.keys(bundle).filter((name) => !name.endsWith('.map'));
      const shellFiles = [
        ...new Set([
          ...emitted.map((name) => `/${name}`),
          ...(await listPublicFiles(PUBLIC_DIR)),
          // The shell itself: install aborts without it (see sw.template.js).
          '/index.html',
          '/manifest.webmanifest',
        ]),
      ].sort();

      const precache = shellFiles.map((file) => `${base}${file.replace(/^\//, '')}`);
      const revision = createHash('sha256')
        .update(`${base}\n${precache.join('\n')}`)
        .digest('hex');
      const cacheName = `tikatrack-v${revision.slice(0, 12)}`;

      const template = await readFile(swPath, 'utf8');
      this.emitFile({
        type: 'asset',
        fileName: 'sw.js',
        source: template
          .split('{{CACHE_NAME}}')
          .join(cacheName)
          .split('{{BASE}}')
          .join(base)
          // The marker comment is replaced too: the emitted worker should not
          // still look like a template, and CI greps for leftover placeholders.
          .replace(
            /\/\* \{\{PRECACHE\}\} \*\/ \[\]/,
            `/* precache, generated at build time */ ${JSON.stringify(precache)}`,
          ),
      });
    },
  };
}

export default defineConfig({
  base,
  plugins: [react(), tailwindcss(), spaFallback(), pwaAssets()],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
    },
  },
  server: {
    host: '0.0.0.0',
    port: 3000,
    strictPort: true,
  },
  preview: {
    host: '0.0.0.0',
    port: 4173,
  },
  build: {
    target: 'es2022',
    // Source maps for the `recharts` chunk are the memory hog; on a constrained
    // machine or container the build can be OOM-killed while rendering chunks.
    // `TIKATRACK_SOURCEMAPS=false npm run build` trades debuggability for a
    // build that finishes. See docs/DEPLOYMENT.md §6.
    sourcemap: process.env.TIKATRACK_SOURCEMAPS !== 'false',
    reportCompressedSize: false,
    chunkSizeWarningLimit: 700,
    rollupOptions: {
      output: {
        // Vendor chunks are split so a data-only change does not invalidate the
        // React or chart bundles that users have already cached.
        manualChunks: {
          react: ['react', 'react-dom', 'react-router-dom'],
          charts: ['recharts'],
          icons: ['lucide-react'],
        },
      },
    },
  },
});
