import { useState, useMemo } from 'react';
import { Calendar, Clock, AlertCircle, TrendingUp, Download, Printer, Filter } from 'lucide-react';
import { allVaccines, schedule, vaccineColors, type Vaccine } from '../data/vaccines';
import { VaccineModal } from './VaccineModal';
import { useI18n } from '../i18n';
import { todayISO } from '../lib/format';
import { calculateAge } from '../lib/smartScheduler';

export default function ScheduleTimeline() {
  const [birthDate, setBirthDate] = useState('');
  const [selectedVaccine, setSelectedVaccine] = useState<Vaccine | null>(null);
  const [ageFilter, setAgeFilter] = useState<string>('all');

  const { t, language } = useI18n();

  // Shared, timezone-safe helper instead of a local copy: `new Date('YYYY-MM-DD')`
  // parses as UTC midnight, so the duplicated version was a day off west of
  // Greenwich and rounded months with a 30.44-day average.
  const age = useMemo(() => (birthDate ? calculateAge(birthDate) : null), [birthDate]);

  // Get vaccine status
  const getVaccineStatus = (ageDays: number) => {
    if (!age) return 'not-due';
    if (age.days >= ageDays + 30) return 'overdue';
    if (age.days >= ageDays) return 'due';
    if (age.days >= ageDays - 30) return 'upcoming';
    return 'not-due';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'overdue':
        return 'bg-red-100 text-red-700 border-red-300';
      case 'due':
        return 'bg-amber-100 text-amber-700 border-amber-300';
      case 'upcoming':
        return 'bg-blue-100 text-blue-700 border-blue-300';
      case 'not-due':
        return 'bg-neutral-100 text-neutral-700 border-neutral-300';
      default:
        return 'bg-neutral-100 text-neutral-700 border-neutral-300';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'overdue':
        return <AlertCircle className="w-5 h-5 text-red-600" />;
      case 'due':
        return <Clock className="w-5 h-5 text-amber-600" />;
      case 'upcoming':
        return <TrendingUp className="w-5 h-5 text-blue-600" />;
      case 'not-due':
        return <Clock className="w-5 h-5 text-neutral-400" />;
      default:
        return <Clock className="w-5 h-5 text-neutral-400" />;
    }
  };

  // Calculate progress
  const calculateProgress = () => {
    if (!age) return { completed: 0, total: 0, percentage: 0 };

    let completed = 0;
    let total = 0;

    schedule.forEach((item) => {
      item.vaccines.forEach(() => {
        total++;
        if (age.days >= item.ageDays) {
          completed++;
        }
      });
    });

    const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;
    return { completed, total, percentage };
  };

  const progress = calculateProgress();

  // Filter schedule by age group
  const filteredSchedule = useMemo(() => {
    if (ageFilter === 'all') return schedule;

    const ageRanges: Record<string, [number, number]> = {
      newborn: [0, 28],
      infant: [29, 365],
      toddler: [366, 1825],
    };

    const [min, max] = ageRanges[ageFilter] || [0, Infinity];
    return schedule.filter((item) => item.ageDays >= min && item.ageDays <= max);
  }, [ageFilter]);

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    // Generate simple text-based schedule
    const content = schedule
      .map(
        (item) =>
          `${item.age[language]}:\n${item.vaccines.map((v) => `  - ${v.name[language]}`).join('\n')}`,
      )
      .join('\n\n');

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `vaccination-schedule-${todayISO()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="animate-slide-up">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-4">
          <div className="bg-gradient-to-br from-emerald-500 to-teal-600 p-3 rounded-xl">
            <Calendar className="w-8 h-8 text-white" />
          </div>
          <h1
            className={`text-4xl font-bold text-neutral-900 dark:text-white ${language === 'bn' ? 'font-bangla' : ''}`}
          >
            {t('schedule.title')}
          </h1>
        </div>
        <p
          className={`text-lg text-neutral-600 dark:text-neutral-300 ${language === 'bn' ? 'font-bangla' : ''}`}
        >
          {t('schedule.subtitle')}
        </p>
      </div>

      {/* Age Calculator */}
      <div className="glass rounded-2xl p-6 mb-8">
        <h3
          className={`text-xl font-bold text-neutral-900 dark:text-white mb-4 ${language === 'bn' ? 'font-bangla' : ''}`}
        >
          {t('schedule.enterBirthDate')}
        </h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <input
              type="date"
              value={birthDate}
              onChange={(e) => setBirthDate(e.target.value)}
              className="input-field"
              max={todayISO()}
            />
          </div>
          {age && (
            <div className="flex items-center gap-4">
              <div className="flex-1">
                <p
                  className={`text-sm text-neutral-600 dark:text-neutral-300 ${language === 'bn' ? 'font-bangla' : ''}`}
                >
                  {t('schedule.currentAge')}
                </p>
                <p className="text-2xl font-bold text-emerald-700 dark:text-emerald-400">
                  {age.months > 0
                    ? `${age.months} ${language === 'en' ? 'months' : 'মাস'}`
                    : age.weeks > 0
                      ? `${age.weeks} ${language === 'en' ? 'weeks' : 'সপ্তাহ'}`
                      : `${age.days} ${language === 'en' ? 'days' : 'দিন'}`}
                </p>
              </div>
              <div className="text-right">
                <p
                  className={`text-sm text-neutral-600 dark:text-neutral-300 ${language === 'bn' ? 'font-bangla' : ''}`}
                >
                  {t('schedule.progress')}
                </p>
                <p className="text-2xl font-bold text-emerald-700 dark:text-emerald-400">
                  {progress.percentage}%
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Progress Bar */}
        {age && (
          <div className="mt-4">
            <div className="w-full bg-neutral-200 dark:bg-neutral-700 rounded-full h-3">
              <div
                className="bg-gradient-to-r from-emerald-500 to-teal-500 h-3 rounded-full transition-all duration-500"
                style={{ width: `${progress.percentage}%` }}
              ></div>
            </div>
            <p
              className={`text-sm text-neutral-600 dark:text-neutral-300 mt-2 ${language === 'bn' ? 'font-bangla' : ''}`}
            >
              {progress.completed} / {progress.total}{' '}
              {language === 'en' ? 'vaccines completed' : 'টি টিকা সম্পন্ন'}
            </p>
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="flex flex-wrap gap-3 mb-6">
        <button onClick={handlePrint} className="btn-secondary flex items-center gap-2">
          <Printer className="w-4 h-4" />
          <span className={language === 'bn' ? 'font-bangla' : ''}>{t('schedule.print')}</span>
        </button>
        <button onClick={handleDownload} className="btn-secondary flex items-center gap-2">
          <Download className="w-4 h-4" />
          <span className={language === 'bn' ? 'font-bangla' : ''}>{t('schedule.download')}</span>
        </button>
        <div className="flex items-center gap-2 ml-auto">
          <Filter className="w-5 h-5 text-neutral-600 dark:text-neutral-300" />
          <select
            value={ageFilter}
            onChange={(e) => setAgeFilter(e.target.value)}
            className="input-field w-auto"
          >
            <option value="all">{t('schedule.all')}</option>
            <option value="newborn">{t('schedule.newborn')}</option>
            <option value="infant">{t('schedule.infant')}</option>
            <option value="toddler">{t('schedule.toddler')}</option>
          </select>
        </div>
      </div>

      {/* Timeline */}
      <div className="relative">
        <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-emerald-500 via-teal-500 to-cyan-500"></div>

        <div className="space-y-6">
          {filteredSchedule.map((item, index) => {
            const status = age ? getVaccineStatus(item.ageDays) : 'not-due';

            return (
              <div
                key={index}
                className="relative flex gap-6 animate-slide-in-right"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                {/* Timeline Dot */}
                <div className="relative z-10 flex-shrink-0">
                  <div
                    className={`w-16 h-16 rounded-full flex items-center justify-center shadow-lg ${
                      status === 'overdue'
                        ? 'bg-gradient-to-br from-red-500 to-red-600'
                        : status === 'due'
                          ? 'bg-gradient-to-br from-amber-500 to-amber-600'
                          : status === 'upcoming'
                            ? 'bg-gradient-to-br from-blue-500 to-blue-600'
                            : 'bg-gradient-to-br from-emerald-500 to-teal-600'
                    }`}
                  >
                    <Clock className="w-8 h-8 text-white" />
                  </div>
                  {status === 'overdue' && (
                    <div className="absolute -top-1 -right-1 w-6 h-6 bg-red-600 rounded-full flex items-center justify-center">
                      <AlertCircle className="w-4 h-4 text-white" />
                    </div>
                  )}
                </div>

                {/* Content Card */}
                <div className="flex-1">
                  <div
                    className={`glass rounded-2xl p-6 hover:shadow-xl transition-all ${
                      status === 'overdue'
                        ? 'border-2 border-red-300'
                        : status === 'due'
                          ? 'border-2 border-amber-300'
                          : 'border border-neutral-200 dark:border-neutral-700'
                    }`}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3
                          className={`text-2xl font-bold text-emerald-700 dark:text-emerald-400 mb-2 ${language === 'bn' ? 'font-bangla' : ''}`}
                        >
                          {item.age[language]}
                        </h3>
                        <div className="flex items-center gap-2">
                          <span
                            className={`px-3 py-1 rounded-full text-xs font-semibold border ${getStatusColor(status)}`}
                          >
                            {status === 'overdue'
                              ? t('schedule.overdue')
                              : status === 'due'
                                ? t('schedule.upcoming')
                                : status === 'upcoming'
                                  ? t('schedule.upcoming')
                                  : t('schedule.notDue')}
                          </span>
                          {age && (
                            <span className="text-sm text-neutral-500 dark:text-neutral-400">
                              {age.days > item.ageDays
                                ? `${age.days - item.ageDays} ${language === 'en' ? 'days ago' : 'দিন আগে'}`
                                : `${item.ageDays - age.days} ${language === 'en' ? 'days left' : 'দিন বাকি'}`}
                            </span>
                          )}
                        </div>
                      </div>
                      {getStatusIcon(status)}
                    </div>

                    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                      {item.vaccines.map((vaccine, vIndex) => {
                        const vaccineData = allVaccines.find((v) => v.id === vaccine.id);
                        const colorConfig =
                          vaccineColors[vaccineData?.color || 'emerald'] || vaccineColors.emerald;
                        return (
                          <div
                            key={vIndex}
                            onClick={() => vaccineData && setSelectedVaccine(vaccineData)}
                            onKeyDown={(e) => {
                              if (vaccineData && (e.key === 'Enter' || e.key === ' ')) {
                                e.preventDefault();
                                setSelectedVaccine(vaccineData);
                              }
                            }}
                            role={vaccineData ? 'button' : undefined}
                            tabIndex={vaccineData ? 0 : undefined}
                            className={`${colorConfig.bg} ${colorConfig.text} ${colorConfig.border} p-4 rounded-xl border shadow-sm transition-all hover:scale-105 hover:shadow-md ${vaccineData ? 'cursor-pointer' : ''}`}
                          >
                            <div className="flex items-center gap-3">
                              <span className="text-3xl">{vaccineData?.icon || '💉'}</span>
                              <div className="flex-1">
                                <p
                                  className={`font-bold ${language === 'bn' ? 'font-bangla' : ''}`}
                                >
                                  {vaccine.name[language]}
                                </p>
                                {vaccineData && (
                                  <p className="text-xs opacity-90">
                                    {vaccineData.efficacy}{' '}
                                    {language === 'en' ? 'effective' : 'কার্যকর'}
                                  </p>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Vaccine Modal */}
      {selectedVaccine && (
        <VaccineModal vaccine={selectedVaccine} onClose={() => setSelectedVaccine(null)} />
      )}
    </div>
  );
}
