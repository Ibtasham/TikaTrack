/**
 * Smart Vaccination Scheduler
 *
 * Intelligent scheduling component that provides:
 * - Automatic age-based vaccination schedules
 * - Date-of-birth-based schedule generation
 * - Dose-by-dose tracking
 * - Upcoming/overdue/completed identification
 * - Next-dose date calculation
 * - Personalized schedules for each family member
 */

import { useState, useMemo } from 'react';
import {
  Calendar,
  Clock,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  Download,
  Printer,
  Search,
  Info,
  Users,
  X,
} from 'lucide-react';
import { useI18n } from '../i18n';
import { todayISO } from '../lib/format';
import {
  generatePersonalizedSchedule,
  calculateAge,
  type ScheduledDose,
} from '../lib/smartScheduler';
import type { Profile } from '../types';

interface SmartSchedulerProps {
  profiles: Profile[];
}

export default function SmartScheduler({ profiles }: SmartSchedulerProps) {
  const [selectedProfile, setSelectedProfile] = useState<string>(profiles[0]?.id || '');
  const [ageFilter, setAgeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDose, setSelectedDose] = useState<ScheduledDose | null>(null);

  const { t, language } = useI18n();

  const currentProfile = profiles.find((p) => p.id === selectedProfile);

  // Generate personalized schedule
  const personalizedSchedule = useMemo(() => {
    if (!currentProfile) return [];
    // The profile, not `profile.records`: the legacy map holds one dose per
    // vaccine, so every dose after the first would show as already given.
    return generatePersonalizedSchedule(currentProfile.dateOfBirth, currentProfile);
  }, [currentProfile]);

  // Calculate age
  const age = currentProfile ? calculateAge(currentProfile.dateOfBirth) : null;

  // Calculate statistics
  const stats = useMemo(() => {
    const completed = personalizedSchedule.filter((d) => d.status === 'completed').length;
    const upcoming = personalizedSchedule.filter((d) => d.status === 'upcoming').length;
    const overdue = personalizedSchedule.filter((d) => d.status === 'overdue').length;
    const dueToday = personalizedSchedule.filter((d) => d.status === 'due-today').length;
    const total = personalizedSchedule.length;
    const progress = total > 0 ? Math.round((completed / total) * 100) : 0;

    return { completed, upcoming, overdue, dueToday, total, progress };
  }, [personalizedSchedule]);

  // Filter schedule
  const filteredSchedule = useMemo(() => {
    let filtered = personalizedSchedule;

    // Age filter
    if (ageFilter !== 'all' && age) {
      filtered = filtered.filter((dose) => {
        const ageDays = dose.scheduledAge.days;
        switch (ageFilter) {
          case 'newborn':
            return ageDays >= 0 && ageDays <= 28;
          case 'infant':
            return ageDays > 28 && ageDays <= 365;
          case 'toddler':
            return ageDays > 365 && ageDays <= 1825;
          case 'child':
            return ageDays > 1825 && ageDays <= 3650;
          case 'adolescent':
            return ageDays > 3650 && ageDays <= 6570;
          case 'adult':
            return ageDays > 6570;
          default:
            return true;
        }
      });
    }

    // Status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter((dose) => dose.status === statusFilter);
    }

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (dose) =>
          dose.vaccineName.en.toLowerCase().includes(query) ||
          dose.vaccineName.bn.includes(searchQuery),
      );
    }

    return filtered;
  }, [personalizedSchedule, ageFilter, statusFilter, searchQuery, age]);

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    // Generate text-based schedule
    const content = personalizedSchedule
      .map((dose) => `${dose.scheduledDate} - ${dose.vaccineName[language]} (${dose.status})`)
      .join('\n');

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `vaccination-schedule-${currentProfile?.name || 'profile'}-${todayISO()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-emerald-100 text-emerald-700 border-emerald-300';
      case 'due-today':
        return 'bg-amber-100 text-amber-700 border-amber-300';
      case 'overdue':
        return 'bg-red-100 text-red-700 border-red-300';
      case 'upcoming':
        return 'bg-blue-100 text-blue-700 border-blue-300';
      default:
        return 'bg-neutral-100 text-neutral-700 border-neutral-300';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-5 h-5 text-emerald-600" />;
      case 'due-today':
        return <Clock className="w-5 h-5 text-amber-600" />;
      case 'overdue':
        return <AlertCircle className="w-5 h-5 text-red-600" />;
      case 'upcoming':
        return <TrendingUp className="w-5 h-5 text-blue-600" />;
      default:
        return <Clock className="w-5 h-5 text-neutral-400" />;
    }
  };

  if (!currentProfile) {
    return (
      <div className="glass rounded-2xl p-12 text-center">
        <Users className="w-16 h-16 text-neutral-300 mx-auto mb-4" />
        <p className={`text-neutral-600 ${language === 'bn' ? 'font-bangla' : ''}`}>
          {language === 'en'
            ? 'No profiles available. Add a family member to get started.'
            : 'কোনো প্রোফাইল নেই। শুরু করতে একটি পরিবারের সদস্য যোগ করুন।'}
        </p>
      </div>
    );
  }

  return (
    <div className="animate-slide-up space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-gradient-to-br from-emerald-500 to-teal-600 p-3 rounded-xl">
              <Calendar className="w-8 h-8 text-white" />
            </div>
            <h1
              className={`text-4xl font-bold text-neutral-900 ${language === 'bn' ? 'font-bangla' : ''}`}
            >
              {t('scheduler.title')}
            </h1>
          </div>
          <p className={`text-lg text-neutral-600 ${language === 'bn' ? 'font-bangla' : ''}`}>
            {t('scheduler.subtitle')}
          </p>
        </div>

        <div className="flex gap-2">
          <button onClick={handlePrint} className="btn-secondary flex items-center gap-2">
            <Printer className="w-4 h-4" />
            <span className={language === 'bn' ? 'font-bangla' : ''}>{t('scheduler.print')}</span>
          </button>
          <button onClick={handleDownload} className="btn-secondary flex items-center gap-2">
            <Download className="w-4 h-4" />
            <span className={language === 'bn' ? 'font-bangla' : ''}>
              {t('scheduler.download')}
            </span>
          </button>
        </div>
      </div>

      {/* Profile Selector and Age Display */}
      <div className="glass rounded-2xl p-6">
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <label
              className={`block text-sm font-medium text-neutral-700 mb-2 ${language === 'bn' ? 'font-bangla' : ''}`}
            >
              {t('scheduler.selectProfile')}
            </label>
            <select
              value={selectedProfile}
              onChange={(e) => setSelectedProfile(e.target.value)}
              className="input-field"
            >
              {profiles.map((profile) => (
                <option key={profile.id} value={profile.id}>
                  {profile.name}
                </option>
              ))}
            </select>
          </div>

          {age && (
            <div className="flex items-end gap-6">
              <div>
                <p
                  className={`text-sm text-neutral-600 mb-1 ${language === 'bn' ? 'font-bangla' : ''}`}
                >
                  {t('scheduler.currentAge')}
                </p>
                <p className="text-2xl font-bold text-emerald-700">
                  {age.years > 0
                    ? `${age.years} ${language === 'en' ? 'years' : 'বছর'}`
                    : age.months > 0
                      ? `${age.months} ${language === 'en' ? 'months' : 'মাস'}`
                      : age.weeks > 0
                        ? `${age.weeks} ${language === 'en' ? 'weeks' : 'সপ্তাহ'}`
                        : `${age.days} ${language === 'en' ? 'days' : 'দিন'}`}
                </p>
              </div>
              <div>
                <p
                  className={`text-sm text-neutral-600 mb-1 ${language === 'bn' ? 'font-bangla' : ''}`}
                >
                  {t('scheduler.progress')}
                </p>
                <p className="text-2xl font-bold text-emerald-700">{stats.progress}%</p>
              </div>
            </div>
          )}
        </div>

        {/* Progress Bar */}
        <div className="mt-4">
          <div className="w-full bg-neutral-200 rounded-full h-3">
            <div
              className="bg-gradient-to-r from-emerald-500 to-teal-500 h-3 rounded-full transition-all duration-500"
              style={{ width: `${stats.progress}%` }}
            ></div>
          </div>
          <div className="flex justify-between mt-2 text-sm">
            <span className="text-neutral-600">
              {stats.completed} {t('scheduler.completed')}
            </span>
            <span className="text-neutral-600">
              {stats.total} {language === 'en' ? 'total' : 'মোট'}
            </span>
          </div>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="glass rounded-2xl p-6">
          <div className="flex items-center justify-between mb-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-600" />
            <span className="text-3xl font-bold text-emerald-700">{stats.completed}</span>
          </div>
          <p className={`text-sm text-neutral-600 ${language === 'bn' ? 'font-bangla' : ''}`}>
            {t('scheduler.completed')}
          </p>
        </div>

        <div className="glass rounded-2xl p-6">
          <div className="flex items-center justify-between mb-2">
            <Clock className="w-8 h-8 text-blue-600" />
            <span className="text-3xl font-bold text-blue-700">{stats.upcoming}</span>
          </div>
          <p className={`text-sm text-neutral-600 ${language === 'bn' ? 'font-bangla' : ''}`}>
            {t('scheduler.upcoming')}
          </p>
        </div>

        <div className="glass rounded-2xl p-6">
          <div className="flex items-center justify-between mb-2">
            <AlertCircle className="w-8 h-8 text-red-600" />
            <span className="text-3xl font-bold text-red-700">{stats.overdue}</span>
          </div>
          <p className={`text-sm text-neutral-600 ${language === 'bn' ? 'font-bangla' : ''}`}>
            {t('scheduler.overdue')}
          </p>
        </div>

        <div className="glass rounded-2xl p-6">
          <div className="flex items-center justify-between mb-2">
            <TrendingUp className="w-8 h-8 text-amber-600" />
            <span className="text-3xl font-bold text-amber-700">{stats.dueToday}</span>
          </div>
          <p className={`text-sm text-neutral-600 ${language === 'bn' ? 'font-bangla' : ''}`}>
            {t('scheduler.dueToday')}
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="glass rounded-2xl p-6">
        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <label
              className={`block text-sm font-medium text-neutral-700 mb-2 ${language === 'bn' ? 'font-bangla' : ''}`}
            >
              {t('scheduler.filterAge')}
            </label>
            <select
              value={ageFilter}
              onChange={(e) => setAgeFilter(e.target.value)}
              className="input-field"
            >
              <option value="all">{t('scheduler.all')}</option>
              <option value="newborn">{t('scheduler.newborn')}</option>
              <option value="infant">{t('scheduler.infant')}</option>
              <option value="toddler">{t('scheduler.toddler')}</option>
              <option value="child">{t('scheduler.child')}</option>
              <option value="adolescent">{t('scheduler.adolescent')}</option>
              <option value="adult">{t('scheduler.adult')}</option>
            </select>
          </div>

          <div>
            <label
              className={`block text-sm font-medium text-neutral-700 mb-2 ${language === 'bn' ? 'font-bangla' : ''}`}
            >
              {t('scheduler.filterStatus')}
            </label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="input-field"
            >
              <option value="all">{t('scheduler.all')}</option>
              <option value="completed">{t('scheduler.completed')}</option>
              <option value="upcoming">{t('scheduler.upcoming')}</option>
              <option value="overdue">{t('scheduler.overdue')}</option>
              <option value="due-today">{t('scheduler.dueToday')}</option>
            </select>
          </div>

          <div>
            <label
              className={`block text-sm font-medium text-neutral-700 mb-2 ${language === 'bn' ? 'font-bangla' : ''}`}
            >
              {t('scheduler.search')}
            </label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t('scheduler.search')}
                className="input-field pl-10"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Schedule Timeline */}
      <div className="glass rounded-2xl p-6">
        <h2
          className={`text-2xl font-bold text-neutral-900 mb-6 ${language === 'bn' ? 'font-bangla' : ''}`}
        >
          {language === 'en' ? 'Vaccination Schedule' : 'টিকাদান সূচি'}
        </h2>

        {filteredSchedule.length === 0 ? (
          <p
            className={`text-neutral-500 text-center py-8 ${language === 'bn' ? 'font-bangla' : ''}`}
          >
            {language === 'en'
              ? 'No vaccines match your filters'
              : 'আপনার ফিল্টারের সাথে কোনো টিকা মিলে না'}
          </p>
        ) : (
          <div className="relative">
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-emerald-500 via-teal-500 to-cyan-500"></div>

            <div className="space-y-6">
              {filteredSchedule.map((dose, index) => (
                <div
                  key={index}
                  className="relative flex gap-6 animate-slide-in-right cursor-pointer hover:scale-[1.02] transition-transform"
                  style={{ animationDelay: `${index * 0.05}s` }}
                  onClick={() => setSelectedDose(dose)}
                >
                  {/* Timeline Dot */}
                  <div className="relative z-10 flex-shrink-0">
                    <div
                      className={`w-16 h-16 rounded-full flex items-center justify-center shadow-lg ${
                        dose.status === 'completed'
                          ? 'bg-gradient-to-br from-emerald-500 to-teal-600'
                          : dose.status === 'overdue'
                            ? 'bg-gradient-to-br from-red-500 to-pink-600'
                            : dose.status === 'due-today'
                              ? 'bg-gradient-to-br from-amber-500 to-orange-600'
                              : 'bg-gradient-to-br from-blue-500 to-cyan-600'
                      }`}
                    >
                      {getStatusIcon(dose.status)}
                    </div>
                  </div>

                  {/* Content Card */}
                  <div className="flex-1">
                    <div
                      className={`glass rounded-2xl p-6 hover:shadow-xl transition-all border-2 ${
                        dose.status === 'completed'
                          ? 'border-emerald-300'
                          : dose.status === 'overdue'
                            ? 'border-red-300'
                            : dose.status === 'due-today'
                              ? 'border-amber-300'
                              : 'border-blue-300'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3
                            className={`text-xl font-bold text-neutral-900 mb-2 ${language === 'bn' ? 'font-bangla' : ''}`}
                          >
                            {dose.vaccineName[language]}
                          </h3>
                          <div className="flex items-center gap-3">
                            <span
                              className={`px-3 py-1 rounded-full text-xs font-semibold border ${getStatusColor(dose.status)}`}
                            >
                              {dose.status === 'completed'
                                ? t('scheduler.completed')
                                : dose.status === 'due-today'
                                  ? t('scheduler.dueToday')
                                  : dose.status === 'overdue'
                                    ? t('scheduler.overdue')
                                    : t('scheduler.upcoming')}
                            </span>
                            <span className="text-sm text-neutral-600">{dose.scheduledDate}</span>
                          </div>
                        </div>
                        <div className="text-right">
                          {dose.status === 'upcoming' && (
                            <p className="text-sm font-semibold text-blue-700">
                              {dose.daysUntilDue} {t('scheduler.daysUntil')}
                            </p>
                          )}
                          {dose.status === 'overdue' && (
                            <p className="text-sm font-semibold text-red-700">
                              {Math.abs(dose.daysUntilDue)} {t('scheduler.daysOverdue')}
                            </p>
                          )}
                          {dose.status === 'due-today' && (
                            <p className="text-sm font-semibold text-amber-700">
                              {t('scheduler.today')}
                            </p>
                          )}
                          {dose.status === 'completed' && dose.actualDate && (
                            <p className="text-sm text-emerald-700">{dose.actualDate}</p>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 text-sm text-neutral-600">
                        <Info className="w-4 h-4" />
                        <span className={language === 'bn' ? 'font-bangla' : ''}>
                          {t('scheduler.recommended')} {dose.scheduledAge.months || 0}{' '}
                          {language === 'en' ? 'months' : 'মাস'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Vaccine Detail Modal */}
      {selectedDose && (
        <div
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in"
          onClick={() => setSelectedDose(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl animate-scale-in"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h2
                    className={`text-2xl font-bold text-neutral-900 mb-2 ${language === 'bn' ? 'font-bangla' : ''}`}
                  >
                    {selectedDose.vaccineName[language]}
                  </h2>
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-semibold border ${getStatusColor(selectedDose.status)}`}
                    >
                      {selectedDose.status === 'completed'
                        ? t('scheduler.completed')
                        : selectedDose.status === 'due-today'
                          ? t('scheduler.dueToday')
                          : selectedDose.status === 'overdue'
                            ? t('scheduler.overdue')
                            : t('scheduler.upcoming')}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedDose(null)}
                  className="p-2 hover:bg-neutral-100 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                {/* Explanation */}
                <div className="bg-blue-50 rounded-xl p-4">
                  <h3
                    className={`font-semibold text-blue-900 mb-2 ${language === 'bn' ? 'font-bangla' : ''}`}
                  >
                    {t('scheduler.why')}
                  </h3>
                  <p className={`text-sm text-blue-800 ${language === 'bn' ? 'font-bangla' : ''}`}>
                    {selectedDose.explanation[language]}
                  </p>
                </div>

                {/* Schedule Info */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-neutral-50 rounded-xl p-4">
                    <p
                      className={`text-sm text-neutral-600 mb-1 ${language === 'bn' ? 'font-bangla' : ''}`}
                    >
                      {t('scheduler.recommended')}
                    </p>
                    <p className="text-lg font-bold text-neutral-900">
                      {selectedDose.scheduledAge.months || 0} {language === 'en' ? 'months' : 'মাস'}
                    </p>
                  </div>
                  <div className="bg-neutral-50 rounded-xl p-4">
                    <p
                      className={`text-sm text-neutral-600 mb-1 ${language === 'bn' ? 'font-bangla' : ''}`}
                    >
                      {t('scheduler.dose')}
                    </p>
                    <p className="text-lg font-bold text-neutral-900">
                      {selectedDose.doseNumber} /{' '}
                      {selectedDose.scheduledDoseCount || selectedDose.totalDoses}
                    </p>
                  </div>
                </div>

                {/* Source */}
                <div className="bg-neutral-50 rounded-xl p-4">
                  <p
                    className={`text-sm text-neutral-600 mb-1 ${language === 'bn' ? 'font-bangla' : ''}`}
                  >
                    {t('scheduler.source')}
                  </p>
                  <p className="text-sm font-medium text-neutral-900">{selectedDose.source}</p>
                  <p
                    className={`text-xs text-neutral-500 mt-1 ${language === 'bn' ? 'font-bangla' : ''}`}
                  >
                    {t('scheduler.verified')}: {selectedDose.lastVerified}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
