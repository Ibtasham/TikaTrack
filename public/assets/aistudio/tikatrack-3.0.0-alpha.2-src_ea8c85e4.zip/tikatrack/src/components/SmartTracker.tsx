/**
 * Smart Vaccination Tracker
 *
 * Intelligent tracking component that provides:
 * - Catch-up vaccination guidance
 * - Intelligent reminders
 * - Family timeline
 * - Progress visualization
 * - Certificate generation
 */

import { useState, useEffect } from 'react';
import { DoseHistory } from './DoseHistory';
import { DoseRecorder } from './DoseRecorder';
import { MemberActions } from './MemberActions';
import { ConfirmDialog } from './ui/ConfirmDialog';
import { Users, Plus, CheckCircle2, Clock, AlertCircle, Trash2, Bell, Award } from 'lucide-react';
import {
  generateCatchUpPlan,
  generateFamilyTimeline,
  calculateVaccinationStats,
} from '../lib/smartScheduler';
import { createProfile } from '../lib/profileStore';
import { useToast } from '../contexts/ToastContext';
import type { Profile } from '../types';
import {
  loadReminderPreferences,
  saveReminderPreferences,
  generateReminders,
  type ReminderPreferences,
} from '../lib/intelligentReminders';
import { useI18n } from '../i18n';
import { todayISO } from '../lib/format';

interface SmartTrackerProps {
  profiles: Profile[];
  setProfiles: (profiles: Profile[]) => void;
}

export default function SmartTracker({ profiles, setProfiles }: SmartTrackerProps) {
  const [selectedProfile, setSelectedProfile] = useState<string>(profiles[0]?.id || '');
  const [showAddProfile, setShowAddProfile] = useState(false);
  const [newProfileName, setNewProfileName] = useState('');
  const [newProfileDob, setNewProfileDob] = useState('');
  const [viewMode, setViewMode] = useState<'overview' | 'timeline' | 'reminders' | 'catchup'>(
    'overview',
  );
  const [preferences, setPreferences] = useState<ReminderPreferences>(loadReminderPreferences());
  const [showPreferences, setShowPreferences] = useState(false);

  const { t, language } = useI18n();
  const toast = useToast();
  const [confirmDeleteProfile, setConfirmDeleteProfile] = useState<string | null>(null);

  const currentProfile = profiles.find((p) => p.id === selectedProfile);

  // Calculate statistics
  const stats = currentProfile
    ? calculateVaccinationStats(currentProfile.dateOfBirth, currentProfile)
    : {
        totalScheduled: 0,
        completed: 0,
        upcoming: 0,
        overdue: 0,
        dueToday: 0,
        progressPercentage: 0,
        dosesRecorded: 0,
        provisional: 0,
        needsReview: 0,
      };

  // Generate catch-up plan
  const catchUpPlan = currentProfile
    ? generateCatchUpPlan(currentProfile.dateOfBirth, currentProfile)
    : [];

  // Generate family timeline
  const familyTimeline = generateFamilyTimeline(profiles);

  // Generate reminders
  useEffect(() => {
    if (currentProfile && preferences.enabled) {
      const reminders = generateReminders(
        currentProfile.id,
        currentProfile.dateOfBirth,
        currentProfile,
        preferences,
      );
      // Save reminders to storage
      localStorage.setItem('tikatrack-reminders', JSON.stringify(reminders));
    }
  }, [currentProfile, preferences]);

  const addProfile = () => {
    // `createProfile` rather than a hand-built object: `Date.now()` ids collide
    // when two members are added in the same millisecond, and validation errors
    // (a future date of birth, an empty name) were silently swallowed.
    const result = createProfile({ name: newProfileName, dateOfBirth: newProfileDob });
    if (!result.profile) {
      toast.error(t('tracker.add.title'), t(`tracker.add.error.${result.error ?? 'name'}`));
      return;
    }
    setProfiles([...profiles, result.profile]);
    setSelectedProfile(result.profile.id);
    setNewProfileName('');
    setNewProfileDob('');
    setShowAddProfile(false);
    toast.success(t('tracker.profileAdded', result.profile.name));
  };

  const deleteProfile = (id: string) => {
    setProfiles(profiles.filter((p) => p.id !== id));
    if (selectedProfile === id) setSelectedProfile(profiles[0]?.id || '');
    setConfirmDeleteProfile(null);
  };

  const updatePreferences = (updates: Partial<ReminderPreferences>) => {
    const newPreferences = { ...preferences, ...updates };
    setPreferences(newPreferences);
    saveReminderPreferences(newPreferences);
  };

  const getAchievements = (profile: Profile) => {
    const stats = calculateVaccinationStats(profile.dateOfBirth, profile);
    const achievements = [];

    if (stats.completed >= 1)
      achievements.push({ icon: '🎯', title: language === 'en' ? 'First Step' : 'প্রথম পদক্ষেপ' });
    if (stats.completed >= 5)
      achievements.push({
        icon: '⭐',
        title: language === 'en' ? 'Rising Star' : 'উদীয়মান তারকা',
      });
    if (stats.completed >= 10)
      achievements.push({ icon: '🏆', title: language === 'en' ? 'Champion' : 'চ্যাম্পিয়ন' });
    if (stats.progressPercentage === 100)
      achievements.push({
        icon: '👑',
        title: language === 'en' ? 'Perfect Record' : 'নিখুঁত রেকর্ড',
      });
    if (stats.overdue === 0)
      achievements.push({ icon: '✅', title: language === 'en' ? 'On Track' : 'সঠিক পথে' });

    return achievements;
  };

  return (
    <div className="animate-slide-up space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-gradient-to-br from-emerald-500 to-teal-600 p-3 rounded-xl">
              <Users className="w-8 h-8 text-white" />
            </div>
            <h1
              className={`text-4xl font-bold text-neutral-900 ${language === 'bn' ? 'font-bangla' : ''}`}
            >
              {t('tracker.title')}
            </h1>
          </div>
          <p className={`text-lg text-neutral-600 ${language === 'bn' ? 'font-bangla' : ''}`}>
            {t('tracker.subtitle')}
          </p>
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => setShowAddProfile(true)}
            className="btn-primary flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span className={language === 'bn' ? 'font-bangla' : ''}>
              {t('tracker.addProfile')}
            </span>
          </button>
          <button
            onClick={() => setShowPreferences(!showPreferences)}
            className="btn-secondary flex items-center gap-2"
          >
            <Bell className="w-4 h-4" />
            <span className={language === 'bn' ? 'font-bangla' : ''}>
              {t('tracker.preferences')}
            </span>
          </button>
        </div>
      </div>

      {/* Preferences Modal */}
      {showPreferences && (
        <div className="glass rounded-2xl p-6 animate-scale-in">
          <h3 className={`text-xl font-bold mb-4 ${language === 'bn' ? 'font-bangla' : ''}`}>
            {t('tracker.reminderSettings')}
          </h3>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className={`text-sm font-medium ${language === 'bn' ? 'font-bangla' : ''}`}>
                {t('tracker.enableReminders')}
              </label>
              <input
                type="checkbox"
                checked={preferences.enabled}
                onChange={(e) => updatePreferences({ enabled: e.target.checked })}
                className="w-5 h-5 text-emerald-600"
              />
            </div>

            <div className="flex items-center justify-between">
              <label className={`text-sm font-medium ${language === 'bn' ? 'font-bangla' : ''}`}>
                {t('tracker.browserNotifications')}
              </label>
              <input
                type="checkbox"
                checked={preferences.browserNotifications}
                onChange={(e) => updatePreferences({ browserNotifications: e.target.checked })}
                className="w-5 h-5 text-emerald-600"
              />
            </div>

            <div>
              <label
                className={`block text-sm font-medium mb-2 ${language === 'bn' ? 'font-bangla' : ''}`}
              >
                {t('tracker.daysBefore')}
              </label>
              <div className="flex gap-2">
                {[7, 3, 1].map((days) => (
                  <label key={days} className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={preferences.daysBefore.includes(days)}
                      onChange={(e) => {
                        const newDays = e.target.checked
                          ? [...preferences.daysBefore, days]
                          : preferences.daysBefore.filter((d) => d !== days);
                        updatePreferences({ daysBefore: newDays });
                      }}
                      className="w-4 h-4 text-emerald-600"
                    />
                    <span className="text-sm">
                      {days} {language === 'en' ? 'days' : 'দিন'}
                    </span>
                  </label>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Profile Modal */}
      {showAddProfile && (
        <div className="glass rounded-2xl p-6 animate-scale-in">
          <h3 className={`text-xl font-bold mb-4 ${language === 'bn' ? 'font-bangla' : ''}`}>
            {t('tracker.addProfile')}
          </h3>
          <div className="grid md:grid-cols-2 gap-4 mb-4">
            <div>
              <label
                className={`block text-sm font-medium mb-2 ${language === 'bn' ? 'font-bangla' : ''}`}
              >
                {t('tracker.name')}
              </label>
              <input
                type="text"
                value={newProfileName}
                onChange={(e) => setNewProfileName(e.target.value)}
                className="input-field"
                placeholder={language === 'en' ? 'Enter name' : 'নাম লিখুন'}
              />
            </div>
            <div>
              <label
                className={`block text-sm font-medium mb-2 ${language === 'bn' ? 'font-bangla' : ''}`}
              >
                {t('tracker.dob')}
              </label>
              <input
                type="date"
                value={newProfileDob}
                onChange={(e) => setNewProfileDob(e.target.value)}
                className="input-field"
                max={todayISO()}
              />
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={addProfile} className="btn-primary">
              <span className={language === 'bn' ? 'font-bangla' : ''}>{t('tracker.save')}</span>
            </button>
            <button onClick={() => setShowAddProfile(false)} className="btn-secondary">
              <span className={language === 'bn' ? 'font-bangla' : ''}>{t('tracker.cancel')}</span>
            </button>
          </div>
        </div>
      )}

      {/* View Mode Selector */}
      {profiles.length > 0 && (
        <div className="flex gap-2">
          {(['overview', 'timeline', 'reminders', 'catchup'] as const).map((mode) => (
            <button
              key={mode}
              onClick={() => setViewMode(mode)}
              className={`px-4 py-2 rounded-xl font-medium transition-all ${
                viewMode === mode
                  ? 'bg-emerald-600 text-white shadow-lg'
                  : 'bg-white text-neutral-700 hover:bg-emerald-50 border'
              }`}
            >
              <span className={language === 'bn' ? 'font-bangla' : ''}>{t(`tracker.${mode}`)}</span>
            </button>
          ))}
        </div>
      )}

      {/* Empty State */}
      {profiles.length === 0 && !showAddProfile && (
        <div className="glass rounded-2xl p-12 text-center">
          <Users className="w-16 h-16 text-neutral-300 mx-auto mb-4" />
          <p className={`text-neutral-600 ${language === 'bn' ? 'font-bangla' : ''}`}>
            {t('tracker.noProfiles')}
          </p>
        </div>
      )}

      {/* Overview View */}
      {viewMode === 'overview' && currentProfile && (
        <div className="space-y-6">
          {/* Profile Card */}
          <div className="glass rounded-2xl p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-4">
                <div className="w-20 h-20 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-full flex items-center justify-center text-white font-bold text-3xl shadow-lg">
                  {currentProfile.name.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h2
                    className={`text-2xl font-bold text-neutral-900 ${language === 'bn' ? 'font-bangla' : ''}`}
                  >
                    {currentProfile.name}
                  </h2>
                  <p className="text-sm text-neutral-600">
                    {language === 'en' ? 'Born' : 'জন্ম'}: {currentProfile.dateOfBirth}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setConfirmDeleteProfile(currentProfile.id)}
                className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                title={t('tracker.member.delete')}
              >
                <Trash2 className="w-5 h-5" />
                <span className="sr-only">{t('tracker.member.delete')}</span>
              </button>
            </div>

            {/* Progress */}
            <div className="mb-4">
              <div className="flex justify-between text-sm mb-2">
                <span className={`text-neutral-600 ${language === 'bn' ? 'font-bangla' : ''}`}>
                  {t('tracker.progress')}
                </span>
                <span className="font-bold text-emerald-700">{stats.progressPercentage}%</span>
              </div>
              <div className="w-full bg-neutral-200 rounded-full h-3">
                <div
                  className="bg-gradient-to-r from-emerald-500 to-teal-500 h-3 rounded-full transition-all duration-500"
                  style={{ width: `${stats.progressPercentage}%` }}
                ></div>
              </div>
            </div>

            {/* Statistics */}
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-emerald-50 rounded-xl p-4 text-center">
                <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
                <p className="text-2xl font-bold text-emerald-700">{stats.completed}</p>
                <p className={`text-sm text-emerald-600 ${language === 'bn' ? 'font-bangla' : ''}`}>
                  {t('tracker.completed')}
                </p>
              </div>
              <div className="bg-blue-50 rounded-xl p-4 text-center">
                <Clock className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <p className="text-2xl font-bold text-blue-700">{stats.upcoming}</p>
                <p className={`text-sm text-blue-600 ${language === 'bn' ? 'font-bangla' : ''}`}>
                  {t('tracker.upcoming')}
                </p>
              </div>
              <div className="bg-red-50 rounded-xl p-4 text-center">
                <AlertCircle className="w-8 h-8 text-red-600 mx-auto mb-2" />
                <p className="text-2xl font-bold text-red-700">{stats.overdue}</p>
                <p className={`text-sm text-red-600 ${language === 'bn' ? 'font-bangla' : ''}`}>
                  {t('tracker.overdue')}
                </p>
              </div>
            </div>

            {/* Record what was actually given: one dose at a time. */}
            <div className="mt-6 pt-6 border-t border-neutral-200">
              <DoseRecorder profile={currentProfile} />
            </div>

            {/* Take the record somewhere useful: calendar, chat app, paper. */}
            <div className="mt-6 pt-6 border-t border-neutral-200">
              <h3
                className={`font-semibold mb-3 flex items-center gap-2 ${language === 'bn' ? 'font-bangla' : ''}`}
              >
                {t('tracker.actions.title')}
              </h3>
              <MemberActions profile={currentProfile} />
            </div>

            {/* Achievements */}
            {getAchievements(currentProfile).length > 0 && (
              <div className="mt-6 pt-6 border-t border-neutral-200">
                <h3
                  className={`font-semibold mb-3 flex items-center gap-2 ${language === 'bn' ? 'font-bangla' : ''}`}
                >
                  <Award className="w-5 h-5 text-amber-600" />
                  {language === 'en' ? 'Achievements' : 'অর্জন'}
                </h3>
                <div className="flex flex-wrap gap-2">
                  {getAchievements(currentProfile).map((achievement, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-100 to-yellow-100 rounded-full text-sm font-semibold text-amber-900"
                    >
                      <span>{achievement.icon}</span>
                      <span className={language === 'bn' ? 'font-bangla' : ''}>
                        {achievement.title}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Every dose this member has, with correction and deletion. */}
          <DoseHistory profile={currentProfile} />
        </div>
      )}

      {/* Timeline View */}
      {viewMode === 'timeline' && (
        <div className="glass rounded-2xl p-6">
          <h2 className={`text-2xl font-bold mb-6 ${language === 'bn' ? 'font-bangla' : ''}`}>
            {t('tracker.timeline')}
          </h2>

          {familyTimeline.length === 0 ? (
            <p
              className={`text-neutral-500 text-center py-8 ${language === 'bn' ? 'font-bangla' : ''}`}
            >
              {language === 'en' ? 'No timeline events yet' : 'এখনো কোনো টাইমলাইন ইভেন্ট নেই'}
            </p>
          ) : (
            <div className="relative">
              <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-emerald-500 via-teal-500 to-cyan-500"></div>

              <div className="space-y-4">
                {familyTimeline.slice(0, 20).map((event, index) => (
                  <div
                    key={index}
                    className="relative flex gap-6 animate-slide-in-right"
                    style={{ animationDelay: `${index * 0.05}s` }}
                  >
                    <div className="relative z-10 flex-shrink-0">
                      <div
                        className={`w-16 h-16 rounded-full flex items-center justify-center shadow-lg ${
                          event.status === 'completed'
                            ? 'bg-gradient-to-br from-emerald-500 to-teal-600'
                            : event.status === 'overdue'
                              ? 'bg-gradient-to-br from-red-500 to-pink-600'
                              : event.status === 'due-today'
                                ? 'bg-gradient-to-br from-amber-500 to-orange-600'
                                : 'bg-gradient-to-br from-blue-500 to-cyan-600'
                        }`}
                      >
                        {event.status === 'completed' ? (
                          <CheckCircle2 className="w-8 h-8 text-white" />
                        ) : event.status === 'overdue' ? (
                          <AlertCircle className="w-8 h-8 text-white" />
                        ) : (
                          <Clock className="w-8 h-8 text-white" />
                        )}
                      </div>
                    </div>

                    <div className="flex-1 glass rounded-2xl p-4">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3
                            className={`font-bold text-neutral-900 ${language === 'bn' ? 'font-bangla' : ''}`}
                          >
                            {event.doseLabel?.[language] ?? event.vaccineName[language]}
                            {event.scheduled === false && typeof event.doseNumber === 'number' && (
                              <span className="ml-1 text-sm font-medium text-neutral-500">
                                · {t('tracker.dose.number', event.doseNumber)}
                              </span>
                            )}
                            {event.scheduled === false && (
                              <span className="badge badge-neutral ml-2 align-middle">
                                {t('tracker.dose.offSchedule')}
                              </span>
                            )}
                          </h3>
                          <p
                            className={`text-sm text-neutral-600 ${language === 'bn' ? 'font-bangla' : ''}`}
                          >
                            {event.profileName} • {event.date}
                          </p>
                        </div>
                        <div
                          className={`px-3 py-1 rounded-full text-xs font-semibold ${
                            event.status === 'completed'
                              ? 'bg-emerald-100 text-emerald-700'
                              : event.status === 'overdue'
                                ? 'bg-red-100 text-red-700'
                                : event.status === 'due-today'
                                  ? 'bg-amber-100 text-amber-700'
                                  : 'bg-blue-100 text-blue-700'
                          }`}
                        >
                          {event.status === 'completed'
                            ? language === 'en'
                              ? 'Completed'
                              : 'সম্পন্ন'
                            : event.status === 'overdue'
                              ? language === 'en'
                                ? 'Overdue'
                                : 'বকেয়া'
                              : event.status === 'due-today'
                                ? language === 'en'
                                  ? 'Due Today'
                                  : 'আজ'
                                : language === 'en'
                                  ? 'Upcoming'
                                  : 'আসন্ন'}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Catch-Up View */}
      {viewMode === 'catchup' && currentProfile && (
        <div className="glass rounded-2xl p-6">
          <h2 className={`text-2xl font-bold mb-2 ${language === 'bn' ? 'font-bangla' : ''}`}>
            {t('tracker.catchUpTitle')}
          </h2>
          <p className={`text-neutral-600 mb-6 ${language === 'bn' ? 'font-bangla' : ''}`}>
            {t('tracker.catchUpSubtitle')}
          </p>

          {catchUpPlan.length === 0 ? (
            <div className="text-center py-12">
              <CheckCircle2 className="w-16 h-16 text-emerald-500 mx-auto mb-4" />
              <p className={`text-lg text-emerald-700 ${language === 'bn' ? 'font-bangla' : ''}`}>
                {t('tracker.noCatchUp')}
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {catchUpPlan.map((plan, index) => (
                <div
                  key={`${plan.vaccineId}-${index}`}
                  className={`rounded-2xl p-6 border-2 ${
                    plan.requiresMedicalAdvice
                      ? 'bg-amber-50 border-amber-300'
                      : 'bg-amber-50 border-amber-300'
                  }`}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3
                        className={`text-xl font-bold text-neutral-900 mb-2 ${language === 'bn' ? 'font-bangla' : ''}`}
                      >
                        {plan.vaccineName[language]}
                      </h3>
                      {plan.requiresMedicalAdvice && (
                        <div className="flex items-center gap-2 text-red-700">
                          <AlertCircle className="w-5 h-5" />
                          <span
                            className={`text-sm font-semibold ${language === 'bn' ? 'font-bangla' : ''}`}
                          >
                            {t('tracker.medicalAdvice')}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>

                  <p
                    className={`text-sm text-neutral-700 mb-4 ${language === 'bn' ? 'font-bangla' : ''}`}
                  >
                    {plan.explanation[language]}
                  </p>

                  {/* Which doses are outstanding, named as the schedule names
                      them, so a parent can ask for the right one. */}
                  <ul className="mb-4 flex flex-wrap gap-2">
                    {plan.missedDoses.map((doseNumber, doseIndex) => (
                      <li key={doseNumber} className="chip">
                        {plan.missedDoseLabels[doseIndex]
                          ? plan.missedDoseLabels[doseIndex][language]
                          : `${plan.vaccineName[language]} · ${t('tracker.dose.number', doseNumber)}`}
                      </li>
                    ))}
                  </ul>

                  <div className="space-y-1 text-sm">
                    <p className={language === 'bn' ? 'font-bangla' : ''}>
                      <span className="text-neutral-600">{t('tracker.catchUp.when')}</span>{' '}
                      <span className="font-semibold">{t('tracker.catchUp.asap')}</span>
                    </p>
                    <p
                      className={`text-xs text-neutral-600 ${language === 'bn' ? 'font-bangla' : ''}`}
                    >
                      {t('tracker.catchUp.noInterval')}
                    </p>
                    {plan.requiresReview && (
                      <p
                        className={`mt-2 flex items-start gap-2 text-xs font-medium text-amber-800 ${language === 'bn' ? 'font-bangla' : ''}`}
                      >
                        <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                        {t('tracker.catchUp.review')}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Removing a member deletes their whole dose history: confirm it. */}
      <ConfirmDialog
        open={confirmDeleteProfile !== null}
        title={t('tracker.member.delete')}
        description={t(
          'tracker.member.deleteBody',
          profiles.find((entry) => entry.id === confirmDeleteProfile)?.name ?? '',
          profiles.find((entry) => entry.id === confirmDeleteProfile)?.events?.length ?? 0,
        )}
        confirmLabel={t('tracker.member.delete')}
        cancelLabel={t('tracker.cancel')}
        tone="danger"
        onConfirm={() => {
          if (confirmDeleteProfile) deleteProfile(confirmDeleteProfile);
        }}
        onCancel={() => setConfirmDeleteProfile(null)}
      />
    </div>
  );
}
