/**
 * Smart Vaccination Dashboard
 *
 * Premium dashboard component that integrates:
 * - Upcoming vaccination cards
 * - Family vaccination timeline
 * - Progress indicators
 * - Overdue vaccination alerts
 * - Calendar integration
 * - Clear status indicators
 */

import { useState } from 'react';
import { Calendar, Clock, AlertCircle, CheckCircle2, TrendingUp, Users } from 'lucide-react';
import {
  generatePersonalizedSchedule,
  generateFamilyTimeline,
  calculateVaccinationStats,
  getOverdueVaccinations,
} from '../lib/smartScheduler';
import { useI18n } from '../i18n';
import { parseISODate } from '../lib/format';

import type { Profile } from '../types';

const DASHBOARD_FILTERS = ['all', 'upcoming', 'overdue', 'completed'] as const;
type DashboardFilter = (typeof DASHBOARD_FILTERS)[number];

function isDashboardFilter(value: string): value is DashboardFilter {
  return (DASHBOARD_FILTERS as readonly string[]).includes(value);
}

interface SmartDashboardProps {
  profiles: Profile[];
}

export default function SmartDashboard({ profiles }: SmartDashboardProps) {
  const [selectedProfile, setSelectedProfile] = useState<string>(profiles[0]?.id || '');
  const [timelineView, setTimelineView] = useState<'month' | 'year' | 'all'>('month');
  const [filterStatus, setFilterStatus] = useState<DashboardFilter>('all');

  const { t, language } = useI18n();

  const currentProfile = profiles.find((p) => p.id === selectedProfile);

  // Calculate statistics
  const stats = currentProfile
    ? calculateVaccinationStats(currentProfile.dateOfBirth, currentProfile)
    : {
        totalScheduled: 0,
        completed: 0,
        upcoming: 0,
        overdue: 0,
        dueToday: 0,
        progressPercentage: 0,
        dosesRecorded: 0,
        provisional: 0,
        needsReview: 0,
      };

  // Get upcoming vaccinations
  const upcomingVaccinations = currentProfile
    ? generatePersonalizedSchedule(currentProfile.dateOfBirth, currentProfile)
        .filter((d) => d.status === 'upcoming' || d.status === 'due-today')
        .slice(0, 5)
    : [];

  // Get overdue vaccinations
  const overdueVaccinations = currentProfile
    ? getOverdueVaccinations(currentProfile.dateOfBirth, currentProfile)
    : [];

  // Generate family timeline
  const familyTimeline = generateFamilyTimeline(profiles);

  // Filter timeline by view
  const filteredTimeline = familyTimeline.filter((event) => {
    // Local calendar date, not UTC midnight — see lib/format.parseISODate.
    const eventDate = parseISODate(event.date);
    if (!eventDate) return true;
    const now = new Date();

    if (timelineView === 'month') {
      const monthAgo = new Date(now);
      monthAgo.setMonth(monthAgo.getMonth() - 1);
      return eventDate >= monthAgo;
    } else if (timelineView === 'year') {
      const yearAgo = new Date(now);
      yearAgo.setFullYear(yearAgo.getFullYear() - 1);
      return eventDate >= yearAgo;
    }
    return true;
  });

  // Filter by status
  const statusFilteredTimeline = filteredTimeline.filter((event) => {
    if (filterStatus === 'all') return true;
    if (filterStatus === 'completed') return event.status === 'completed';
    if (filterStatus === 'upcoming')
      return event.status === 'upcoming' || event.status === 'due-today';
    if (filterStatus === 'overdue') return event.status === 'overdue';
    return true;
  });

  if (!currentProfile) {
    return (
      <div className="glass rounded-2xl p-12 text-center">
        <Users className="w-16 h-16 text-neutral-300 mx-auto mb-4" />
        <p className={`text-neutral-600 ${language === 'bn' ? 'font-bangla' : ''}`}>
          {language === 'en'
            ? 'No profiles available. Add a family member to get started.'
            : 'কোনো প্রোফাইল নেই। শুরু করতে একটি পরিবারের সদস্য যোগ করুন।'}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1
            className={`text-4xl font-bold text-neutral-900 ${language === 'bn' ? 'font-bangla' : ''}`}
          >
            {t('dashboard.title')}
          </h1>
          <p className={`text-lg text-neutral-600 mt-2 ${language === 'bn' ? 'font-bangla' : ''}`}>
            {t('dashboard.subtitle')}
          </p>
        </div>

        {/* Profile Selector */}
        <select
          value={selectedProfile}
          onChange={(e) => setSelectedProfile(e.target.value)}
          className="input-field w-auto"
        >
          {profiles.map((profile) => (
            <option key={profile.id} value={profile.id}>
              {profile.name}
            </option>
          ))}
        </select>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="glass rounded-2xl p-6">
          <div className="flex items-center justify-between mb-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-600" />
            <span className="text-3xl font-bold text-emerald-700">{stats.completed}</span>
          </div>
          <p className={`text-sm text-neutral-600 ${language === 'bn' ? 'font-bangla' : ''}`}>
            {t('dashboard.completed')}
          </p>
        </div>

        <div className="glass rounded-2xl p-6">
          <div className="flex items-center justify-between mb-2">
            <Clock className="w-8 h-8 text-blue-600" />
            <span className="text-3xl font-bold text-blue-700">{stats.upcoming}</span>
          </div>
          <p className={`text-sm text-neutral-600 ${language === 'bn' ? 'font-bangla' : ''}`}>
            {t('dashboard.upcoming')}
          </p>
        </div>

        <div className="glass rounded-2xl p-6">
          <div className="flex items-center justify-between mb-2">
            <AlertCircle className="w-8 h-8 text-red-600" />
            <span className="text-3xl font-bold text-red-700">{stats.overdue}</span>
          </div>
          <p className={`text-sm text-neutral-600 ${language === 'bn' ? 'font-bangla' : ''}`}>
            {t('dashboard.overdue')}
          </p>
        </div>

        <div className="glass rounded-2xl p-6">
          <div className="flex items-center justify-between mb-2">
            <TrendingUp className="w-8 h-8 text-purple-600" />
            <span className="text-3xl font-bold text-purple-700">{stats.progressPercentage}%</span>
          </div>
          <p className={`text-sm text-neutral-600 ${language === 'bn' ? 'font-bangla' : ''}`}>
            {t('dashboard.progress')}
          </p>
          <div className="w-full bg-neutral-200 rounded-full h-2 mt-2">
            <div
              className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full transition-all"
              style={{ width: `${stats.progressPercentage}%` }}
            ></div>
          </div>
        </div>
      </div>

      {/* Two Column Layout */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Upcoming Vaccinations */}
        <div className="glass rounded-2xl p-6">
          <h2
            className={`text-2xl font-bold text-neutral-900 mb-4 flex items-center gap-2 ${language === 'bn' ? 'font-bangla' : ''}`}
          >
            <Calendar className="w-6 h-6 text-blue-600" />
            {t('dashboard.upcomingVaccinations')}
          </h2>

          {upcomingVaccinations.length === 0 ? (
            <p
              className={`text-neutral-500 text-center py-8 ${language === 'bn' ? 'font-bangla' : ''}`}
            >
              {t('dashboard.noUpcoming')}
            </p>
          ) : (
            <div className="space-y-3">
              {upcomingVaccinations.map((dose, index) => (
                <div
                  key={index}
                  className="bg-gradient-to-r from-blue-50 to-cyan-50 rounded-xl p-4 border border-blue-200 hover:shadow-md transition-all"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3
                        className={`font-bold text-neutral-900 mb-1 ${language === 'bn' ? 'font-bangla' : ''}`}
                      >
                        {dose.vaccineName[language]}
                      </h3>
                      <p
                        className={`text-sm text-neutral-600 ${language === 'bn' ? 'font-bangla' : ''}`}
                      >
                        {dose.scheduledDate} •{' '}
                        {dose.daysUntilDue === 0
                          ? t('dashboard.today')
                          : `${dose.daysUntilDue} ${t('dashboard.daysUntil')}`}
                      </p>
                    </div>
                    <div
                      className={`px-3 py-1 rounded-full text-xs font-semibold ${
                        dose.status === 'due-today'
                          ? 'bg-amber-100 text-amber-700'
                          : 'bg-blue-100 text-blue-700'
                      }`}
                    >
                      {dose.status === 'due-today'
                        ? language === 'en'
                          ? 'Due Today'
                          : 'আজ'
                        : language === 'en'
                          ? 'Upcoming'
                          : 'আসন্ন'}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Overdue Vaccinations */}
        <div className="glass rounded-2xl p-6">
          <h2
            className={`text-2xl font-bold text-neutral-900 mb-4 flex items-center gap-2 ${language === 'bn' ? 'font-bangla' : ''}`}
          >
            <AlertCircle className="w-6 h-6 text-red-600" />
            {t('dashboard.overdueVaccinations')}
          </h2>

          {overdueVaccinations.length === 0 ? (
            <p
              className={`text-neutral-500 text-center py-8 ${language === 'bn' ? 'font-bangla' : ''}`}
            >
              {t('dashboard.noOverdue')}
            </p>
          ) : (
            <div className="space-y-3">
              {overdueVaccinations.map((dose, index) => (
                <div
                  key={index}
                  className="bg-gradient-to-r from-red-50 to-pink-50 rounded-xl p-4 border border-red-200 hover:shadow-md transition-all"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3
                        className={`font-bold text-neutral-900 mb-1 ${language === 'bn' ? 'font-bangla' : ''}`}
                      >
                        {dose.vaccineName[language]}
                      </h3>
                      <p
                        className={`text-sm text-neutral-600 ${language === 'bn' ? 'font-bangla' : ''}`}
                      >
                        {dose.scheduledDate} • {Math.abs(dose.daysUntilDue)}{' '}
                        {t('dashboard.daysOverdue')}
                      </p>
                    </div>
                    <div className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-xs font-semibold">
                      {language === 'en' ? 'Overdue' : 'বকেয়া'}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Family Timeline */}
      <div className="glass rounded-2xl p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <h2
            className={`text-2xl font-bold text-neutral-900 flex items-center gap-2 ${language === 'bn' ? 'font-bangla' : ''}`}
          >
            <Users className="w-6 h-6 text-emerald-600" />
            {t('dashboard.timeline')}
          </h2>

          <div className="flex gap-2">
            {/* View Toggle */}
            <div className="flex gap-1 bg-neutral-100 rounded-lg p-1">
              {(['month', 'year', 'all'] as const).map((view) => (
                <button
                  key={view}
                  onClick={() => setTimelineView(view)}
                  className={`px-3 py-1 rounded-md text-sm font-medium transition-all ${
                    timelineView === view
                      ? 'bg-white text-emerald-700 shadow-sm'
                      : 'text-neutral-600 hover:text-emerald-700'
                  }`}
                >
                  {t(`dashboard.${view}`)}
                </button>
              ))}
            </div>

            {/* Status Filter */}
            <select
              value={filterStatus}
              onChange={(event) => {
                const { value } = event.target;
                if (isDashboardFilter(value)) setFilterStatus(value);
              }}
              className="input-field w-auto text-sm"
            >
              <option value="all">{language === 'en' ? 'All Status' : 'সব স্ট্যাটাস'}</option>
              <option value="completed">{t('dashboard.completed')}</option>
              <option value="upcoming">{t('dashboard.upcoming')}</option>
              <option value="overdue">{t('dashboard.overdue')}</option>
            </select>
          </div>
        </div>

        {statusFilteredTimeline.length === 0 ? (
          <p
            className={`text-neutral-500 text-center py-8 ${language === 'bn' ? 'font-bangla' : ''}`}
          >
            {language === 'en' ? 'No events in this time period' : 'এই সময়ে কোনো ইভেন্ট নেই'}
          </p>
        ) : (
          <div className="relative">
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-emerald-500 via-teal-500 to-cyan-500"></div>

            <div className="space-y-4">
              {statusFilteredTimeline.slice(0, 10).map((event, index) => (
                <div
                  key={index}
                  className="relative flex gap-6 animate-slide-in-right"
                  style={{ animationDelay: `${index * 0.05}s` }}
                >
                  {/* Timeline Dot */}
                  <div className="relative z-10 flex-shrink-0">
                    <div
                      className={`w-16 h-16 rounded-full flex items-center justify-center shadow-lg ${
                        event.status === 'completed'
                          ? 'bg-gradient-to-br from-emerald-500 to-teal-600'
                          : event.status === 'overdue'
                            ? 'bg-gradient-to-br from-red-500 to-pink-600'
                            : event.status === 'due-today'
                              ? 'bg-gradient-to-br from-amber-500 to-orange-600'
                              : 'bg-gradient-to-br from-blue-500 to-cyan-600'
                      }`}
                    >
                      {event.status === 'completed' ? (
                        <CheckCircle2 className="w-8 h-8 text-white" />
                      ) : event.status === 'overdue' ? (
                        <AlertCircle className="w-8 h-8 text-white" />
                      ) : (
                        <Clock className="w-8 h-8 text-white" />
                      )}
                    </div>
                  </div>

                  {/* Event Card */}
                  <div className="flex-1 glass rounded-2xl p-4 hover:shadow-xl transition-all">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3
                          className={`font-bold text-neutral-900 ${language === 'bn' ? 'font-bangla' : ''}`}
                        >
                          {event.vaccineName[language]}
                        </h3>
                        <p
                          className={`text-sm text-neutral-600 ${language === 'bn' ? 'font-bangla' : ''}`}
                        >
                          {event.profileName} • {event.date}
                        </p>
                      </div>
                      <div
                        className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          event.status === 'completed'
                            ? 'bg-emerald-100 text-emerald-700'
                            : event.status === 'overdue'
                              ? 'bg-red-100 text-red-700'
                              : event.status === 'due-today'
                                ? 'bg-amber-100 text-amber-700'
                                : 'bg-blue-100 text-blue-700'
                        }`}
                      >
                        {event.status === 'completed'
                          ? language === 'en'
                            ? 'Completed'
                            : 'সম্পন্ন'
                          : event.status === 'overdue'
                            ? language === 'en'
                              ? 'Overdue'
                              : 'বকেয়া'
                            : event.status === 'due-today'
                              ? language === 'en'
                                ? 'Due Today'
                                : 'আজ'
                              : language === 'en'
                                ? 'Upcoming'
                                : 'আসন্ন'}
                      </div>
                    </div>
                    {event.notes && (
                      <p
                        className={`text-sm text-neutral-500 mt-2 ${language === 'bn' ? 'font-bangla' : ''}`}
                      >
                        {event.notes}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {statusFilteredTimeline.length > 10 && (
              <p
                className={`text-center text-neutral-500 mt-4 ${language === 'bn' ? 'font-bangla' : ''}`}
              >
                {language === 'en'
                  ? `Showing 10 of ${statusFilteredTimeline.length} events`
                  : `${statusFilteredTimeline.length}টি ইভেন্টের মধ্যে ১০টি দেখানো হচ্ছে`}
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
