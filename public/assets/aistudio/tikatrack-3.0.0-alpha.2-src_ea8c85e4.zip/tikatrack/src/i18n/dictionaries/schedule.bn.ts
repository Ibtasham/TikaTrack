/* ---------------------------------------------------------------------------
 * Bangla (বাংলা) strings.
 *
 * Kept in sync with the other language file: `npm run test` fails when a key
 * exists in one language but not the other.
 * ------------------------------------------------------------------------- */
import type { TranslationDictionary } from '../types';

export const bn: TranslationDictionary = {
  'schedule.title': 'টিকাদান সূচি',
  'schedule.subtitle': 'ইন্টারেক্টিভ বয়স-ভিত্তিক টিকাদান সময়রেখা',
  'schedule.enterBirthDate': 'জন্ম তারিখ লিখুন',
  'schedule.calculateAge': 'সূচি গণনা করুন',
  'schedule.currentAge': 'বর্তমান বয়স',
  'schedule.completed': 'সম্পন্ন',
  'schedule.upcoming': 'আসন্ন',
  'schedule.overdue': 'বকেয়া',
  'schedule.notDue': 'এখনো সময় হয়নি',
  'schedule.progress': 'অগ্রগতি',
  'schedule.filter': 'বয়স অনুযায়ী ফিল্টার',
  'schedule.all': 'সব',
  'schedule.newborn': 'নবজাতক',
  'schedule.infant': 'শিশু',
  'schedule.toddler': 'টডলার',
  'schedule.print': 'সূচি প্রিন্ট করুন',
  'schedule.download': 'PDF ডাউনলোড করুন',
};
