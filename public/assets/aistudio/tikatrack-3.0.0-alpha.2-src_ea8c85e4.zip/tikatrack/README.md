<div align="center">

# 💉 TikaTrack

**Never miss a vaccine.** A free, bilingual (English / বাংলা) vaccination
information, scheduling and tracking platform for Bangladesh — built to work
**offline-first**, on any device, with no account required.

[![CI](https://img.shields.io/badge/CI-passing-brightgreen)](.github/workflows/ci.yml)
[![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Node](https://img.shields.io/badge/node-%3E%3D20.19-339933)](package.json)
[![Code style: Prettier](https://img.shields.io/badge/code_style-Prettier-ff69b4)](.prettierrc.json)

</div>

---

## What is TikaTrack?

TikaTrack helps families and health workers in Bangladesh keep track of
vaccinations. It answers three questions:

1. **Which vaccines are needed, and when?** — an age-based schedule built from
   the national EPI programme, with a source citation for every vaccine.
2. **What has my family already received?** — a local-first tracker for multiple
   members, with catch-up planning for missed doses.
3. **What is due next?** — reminders, a dashboard, and printable records.

Everything runs in the browser. **There is no server to trust and no account to
create** — your data lives in `localStorage` on your device. Cloud sync is
available _only_ if you configure Supabase yourself (see
[Configuration](#configuration)).

> [!IMPORTANT]
> TikaTrack is an **information and record-keeping tool, not a medical device**.
> It does not give medical advice. Always confirm schedules, eligibility and
> symptoms with a qualified health professional or an official source
> (WHO Bangladesh, DGHS / EPI, your local EPI centre). National hotline: **16263**.

## Features

- 🌐 **Fully bilingual** — every string ships in English and বাংলা, with Bangla
  numerals, month names and a proper Bangla font stack. Switchable at runtime.
- 📴 **Offline-first, for real** — a service worker precaches the app shell, so a
  reload with no network still opens the app; hashed assets are cache-first and
  navigations fall back to the cached SPA shell. Installable (templated manifest
  with base-correct scope, icons and four home-screen shortcuts), with an honest
  status banner: _offline_, _offline ready_, _update available_.
- 💉 **52 vaccine references**, each classified against the 3.0 evidence
  taxonomy (national routine EPI, national campaign, supplementary activity,
  special-risk, travel, occupational, private market, international reference,
  planned introduction, research-only). Every entry states its review status,
  and unverified content is labelled as such rather than presented as fact.
- 📚 **Evidence layer** — a source registry, structured clinical records, a
  conflict register and a validator that fails CI when a medical claim is
  marked verified without a sufficient source. See
  [Evidence-backed knowledge base](#evidence-backed-knowledge-base).
- 🗓️ **Smart scheduler** — personalised, date-of-birth-driven schedules that
  match each recorded dose to its own slot in a series, with a **catch-up
  listing** of the doses still outstanding. Catch-up _dates_ are deliberately not
  generated yet: no authoritative minimum-interval table for Bangladesh is
  registered (see `docs/EVIDENCE-REVIEW.md`).
- 👨‍👩‍👧 **Family tracking** — unlimited members, and **every dose recorded
  separately**: a per-dose ledger (`VaccinationEvent`) holds the dose number, the
  schedule slot it fills, the date it was given, the centre, manufacturer, batch,
  notes, who wrote it (`manual` / `import` / `legacy-migration` / `verified`) and
  whether it needs a human to confirm it. Record dose 1, 2, 3 and boosters
  independently, correct one date without touching the others, delete one dose
  behind a confirmation that names it, and see the whole history per member.
  2.x data migrates additively: nothing is dropped and **no dose number is ever
  invented** — an unnumbered legacy record is flagged for review instead.
- 🏥 **99 vaccination centres** across 8 divisions and 59 districts —
  filterable, searchable, sortable, exportable, with phone/one-tap directions.
  Centre "verification" metadata is asserted by the dataset but is not yet
  evidenced by document-level sources; that gap is tracked in the audit.
- 🔔 **Reminders** — derived from each member's schedule (never stale), with
  optional opt-in browser notifications, quiet hours and lead-time choices.
- 🤖 **TikaBot** — an offline retrieval assistant that answers only from the
  bundled, sourced knowledge base, flags emergencies, and says "I don't know"
  rather than guessing. Pick a family member and it adds what _your_ saved record
  says — in a separate, clearly-labelled panel, never mixed into a sourced quote.
- 📊 **Analytics** — completion, overdue and 12-month activity charts
  (Recharts), all derived from the same scheduler the tracker uses.
- 🆚 **Compare** vaccines side by side.
- 📅 **Calendar export** — one member's remaining doses, the whole family, or the
  reminder list, as a standards-compliant `.ics` file whose alarms are your own
  reminder settings. Re-importing updates instead of duplicating.
- 📤 **Share & print** — one CSV row per administered dose, a JSON backup that
  carries the whole ledger, and a ready-made bilingual record summary for
  WhatsApp or
  Messenger (Web Share API, clipboard fallback), and a one-page EPI card for the
  health worker, with the passport QR printed on it.
- 📷 **Scan to verify** — point a camera at a certificate QR, or upload a photo of
  a printed card. Decoding happens on the device; nothing is uploaded.
- 🪪 **Digital passport** — a device-signed QR certificate with a verifier
  (honest about the limits of device-bound signing), shareable as a PNG.
- 🌗 **Dark mode** — light / dark / system, applied before first paint (no flash).
- 👋 **First-run tour** — three steps (where your data lives, what to do first,
  what works offline), skipped automatically on a device that already holds
  records, and dismissed for good by Escape, Skip or Get started.
- ♿ **Accessible** — skip link, one shared focus trap behind every dialog and
  popover, ARIA labels, reduced-motion support, screen-reader-friendly counters,
  and a **text-size control** (normal / large / x-large) applied before first
  paint.

## Tech stack

| Concern | Choice                                                              |
| ------- | ------------------------------------------------------------------- |
| UI      | React 18, TypeScript 5.9 (strict), React Router 7                   |
| Styling | Tailwind CSS 4 (`@tailwindcss/vite`), CSS-first `@theme`/`@utility` |
| Build   | Vite 6, manual chunk-splitting, lazy routes, source maps            |
| Charts  | Recharts (code-split)                                               |
| Icons   | lucide-react                                                        |
| Tests   | Vitest 4 + jsdom + Testing Library (809 tests, ~93% coverage)       |
| Quality | ESLint 10 (flat config), Prettier 3, `npm run validate`             |
| Audit   | `npm audit` clean — 0 vulnerabilities, production **and** dev       |
| Backend | Optional Supabase (`@supabase/supabase-js`) — off by default        |
| QR      | Hand-written byte-mode encoder (versions 1–12, ECC-M), no deps      |
| Scan    | `jsQR` (dynamically imported, so it never enters the main bundle)   |
| PWA     | Hand-written service worker + templated manifest — no plugin        |
| Export  | `.ics` (RFC 5545), CSV, JSON, print — all generated on the device   |

## Quick start

**Prerequisites:** Node.js **≥ 20.19** and npm.

```bash
npm install        # install dependencies
npm run dev        # start the dev server (http://localhost:3000)
```

Open http://localhost:3000. That's it — no environment variables, no database,
no accounts. The app is fully functional.

```bash
npm run build      # type-check, then build an optimised bundle to dist/
npm run preview    # serve the production build locally (http://localhost:4173)
```

> [!TIP]
> If the build is killed for memory (exit 137) on a small machine or in a
> container, run `TIKATRACK_SOURCEMAPS=false npm run build` — the `recharts`
> source map is the memory hog. See
> [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md#6-troubleshooting-the-build).

## Scripts

| Script                  | What it does                                                                            |
| ----------------------- | --------------------------------------------------------------------------------------- |
| `npm run dev`           | Start the Vite dev server                                                               |
| `npm run build`         | `tsc -b` then `vite build` → `dist/`                                                    |
| `npm run preview`       | Serve the production build                                                              |
| `npm run typecheck`     | Type-check the whole project (no emit)                                                  |
| `npm run lint`          | ESLint (flat config)                                                                    |
| `npm run lint:fix`      | ESLint with `--fix`                                                                     |
| `npm run format`        | Prettier write                                                                          |
| `npm run format:check`  | Prettier check (used in CI)                                                             |
| `npm run test`          | Run the Vitest suite once                                                               |
| `npm run test:watch`    | Vitest in watch mode                                                                    |
| `npm run test:coverage` | Vitest with v8 coverage                                                                 |
| **`npm run validate`**  | **typecheck → lint → format:check → evidence:report → test:coverage → build** (CI gate) |

## Evidence-backed knowledge base

TikaTrack 3.0 turns the vaccine catalogue into a structured, versioned and
source-verifiable knowledge base. Four pieces, all in the repository:

| Piece              | Path                                                         | What it does                                                                                                                                                                                                                                             |
| ------------------ | ------------------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Source registry    | `src/data/evidence/sources.ts`                               | Every citation: publisher, title, document-level URL, publication date, access date, section, the claims it supports, and how it was checked.                                                                                                            |
| Structured records | `src/data/evidence/records.ts`                               | One record per vaccine: antigens, type, target population, programme class, dose sequence, minimum interval, maximum age, contraindications, precautions, adverse events, efficacy, references, effective/superseded/last-reviewed dates, review status. |
| Conflict register  | `src/data/evidence/conflicts.ts`                             | Where sources disagree, both statements are recorded with their evidence. Conflicts are never merged or silently resolved.                                                                                                                               |
| Validator + report | `src/lib/evidenceValidator.ts`, `scripts/evidence-report.ts` | `npm run evidence:report` regenerates `docs/EVIDENCE-REVIEW.md` and exits non-zero on any blocking finding.                                                                                                                                              |

**Source hierarchy.** Bangladesh DGHS/EPI and ministry circulars first, then WHO
country immunization data, WHO position papers and technical guidance, then
UNICEF and Gavi, then other recognised public-health authorities for general
vaccine information. An international schedule is never assumed to be
appropriate for Bangladesh.

**A homepage is not a citation.** `https://www.who.int`, `https://dghs.gov.bd`
and `https://www.gavi.org` are registered with
`sufficiency: 'insufficient-for-clinical'`, so citing one for a dosing,
interval, contraindication or efficacy claim is a hard error in CI. 21 legacy
entries cite the WHO homepage; they are reported, not silently accepted.

**Nothing is invented.** As of 2026-10-31 no official Bangladeshi schedule
document had been obtained and read, so every dose age is transcribed from the
2.x dataset and marked `requires-professional-review`, and **no minimum age,
minimum interval or maximum age exists anywhere in the data** — a test fails if
one appears without evidence. The gap itself is registered as a source
(`no-official-schedule-document`) so it is visible instead of implied.

Regenerate the report:

```bash
npm run evidence:report   # writes docs/EVIDENCE-REVIEW.md, fails on blocking findings
```

## Configuration

TikaTrack needs **no configuration** to run. All of the following are optional.

Copy `.env.example` to `.env.local` (git-ignored) to override defaults:

| Variable                 | Purpose                                                   |
| ------------------------ | --------------------------------------------------------- |
| `VITE_SUPABASE_URL`      | Enables cloud accounts + sync. Empty ⇒ local-only mode.   |
| `VITE_SUPABASE_ANON_KEY` | Paired with the URL above.                                |
| `VITE_APP_NAME`          | Display name (defaults to `TikaTrack`).                   |
| `VITE_BASE`              | Base path for sub-directory deploys (e.g. `/tikatrack/`). |

**Offline-first guarantee:** when the Supabase variables are absent, no client
is created and **no network request is made**. Auth becomes a local,
password-hashed account stored on-device; profiles, reminders and the passport
all persist in `localStorage`. When the variables are present, cloud sync
activates automatically. See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

## Project structure

```
src/
├── main.tsx            # entry; SPA-redirect resolution + provider mount
├── App.tsx             # provider stack (router, theme, i18n, toast, auth, profiles)
├── router.tsx          # route table; heavy/rare routes are lazy-loaded
├── layout/             # Header, Footer, Layout shell, ScrollToTop
├── pages/              # one component per route (Home, Vaccines, Tracker, …)
├── components/         # reusable UI (cards, dialogs, skeletons, charts, …)
│                       #   + DoseRecorder, DoseHistory, MemberActions,
│                       #   + QrScanner, TextSizeButton, AppStatus
├── contexts/           # Theme, I18n, Toast, Auth, Profiles providers
├── hooks/              # shared hooks
├── i18n/               # runtime i18n + per-namespace dictionaries (en/bn)
├── data/               # vaccines, centres, schedule, FAQ knowledge base
│                       #   + evidence/ (sources, records, conflicts, bridge)
├── lib/                # pure logic: format, profileStore, doseLedger,
│                       #   doseExport, smartScheduler, intelligentReminders,
│                       #   ragEngine, evidenceValidator, qr, qrScanner,
│                       #   digitalPassport, localAuth, supabase, storage,
│                       #   exporters, ics, share, epiCard, botContext,
│                       #   serviceWorker, id, version, spaRedirect
├── styles/index.css    # Tailwind v4 theme + component/utility layer
├── types/              # shared domain types
└── tests/              # Vitest suites (unit, component + two smoke passes)

docs/                   # ARCHITECTURE, DEPLOYMENT, LOCALISATION, CHANGELOG,
                        #   DATA-CHANGELOG, EVIDENCE-REVIEW
supabase/migrations/    # optional SQL schema for cloud mode
scripts/                # i18n + icon generators
public/                 # icons, robots, favicon, OG cover
404.template.html       # emitted as dist/404.html with VITE_BASE baked in
manifest.template.json  # emitted as dist/manifest.webmanifest (base-aware)
sw.template.js          # emitted as dist/sw.js with the bundle's precache list
```

The guiding rule: **`lib/` and `data/` are pure** (no React, no I/O side effects
beyond explicit storage helpers), so they are unit-testable and reusable by both
the local and cloud paths. Pages compose contexts + lib; components stay presentational.

## Testing

```bash
npm run test
```

**809 tests across 33 suites.** They cover the QR encoder (round-trips verified
against the independent `jsQR` decoder), the scanner that reads those codes back,
the `.ics` calendar writer, the share/clipboard layer, the printable EPI card, the
assistant's record-aware context block, the service worker and its hooks —
including the _generated_ worker's `install`/`activate`/`fetch` handlers, driven
against a fake `Cache` in jsdom — the portable SHA-256 (checked against
Node's own implementation), the scheduler and reminder engine — re-run with the
timezone pinned to UTC, Asia/Dhaka, America/New_York and Pacific/Kiritimati — the
dose ledger (schema, migration, per-dose attribution, merging, every validation
error), the profile store and import/export format, the six dose-record
regressions driven end to end through the store and back out through the
scheduler and the exporters, the dose recorder and dose history driven through
the real screens — record, correct, delete with and without confirming, delete a
whole series, confirm a migrated record — local accounts (including sign-in on an
insecure origin where SubtleCrypto is missing), the RAG assistant, date/number
formatting, storage migration and failure modes, CSV/JSON/print/clipboard
exporters, i18n parity **and aggregation**, the Supabase adapter (scripted through
a fake client, so the cloud path is tested offline), and **two** full-app smoke
passes — every route mounted against empty storage (the first-run experience)
_and_ against a populated device (a member, a dose, derived reminders, an issued
passport), which is the only state in which the calendar, share, print, scan and
record-aware features exist at all. The first-run tour is tested both ways too: as
a decision table (`lib/onboarding`) and as a dialog driven through the real app.

`npm run test:coverage` enforces thresholds over `lib/`, `data/`, `hooks/` and
`i18n/` — 90% lines, statements and functions, 82% branches — and currently
measures **93.6% lines / 92.2% statements / 92.9% functions / 85.3% branches**.
`npm run validate` runs that gate, so a drop in coverage fails the build.

## Deployment

Static hosting only — build and upload `dist/`. Full instructions, including
GitHub Pages (whose `dist/404.html` fallback is generated at build time with your
base path baked in), Netlify/Vercel/Cloudflare rewrites, sub-path deploys via
`VITE_BASE`, and enabling Supabase, are in
[`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md).

## Data & sources

Vaccine and centre data is bundled in `src/data/` and each vaccine carries a
`source` / `sourceUrl`. This data is provided **as-is for information only**; it
can lag behind the current national schedule. Verify against
[WHO Bangladesh](https://www.who.int/bangladesh), DGHS / EPI, or a health
professional before making any medical decision. See the in-app
**About** and **Privacy** pages.

## Contributing

Contributions are welcome. Please run `npm run validate` before opening a pull
request — CI runs the same gate. Keep new user-facing strings in **both**
`i18n/dictionaries/*.en.ts` and `*.bn.ts` (the parity test enforces it). See
[`docs/LOCALISATION.md`](docs/LOCALISATION.md) and
[`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

## License

MIT © 2026 TikaTrack contributors — see [`LICENSE`](LICENSE).
